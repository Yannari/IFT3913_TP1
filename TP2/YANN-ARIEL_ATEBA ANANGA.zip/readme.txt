TP2 IFT3913
YANN-ARIEL ANANGA (20172516)
Rapport -> Rapport.pdf
Repo:https://github.com/Yannari/IFT3913_TP1/tree/main/TP2

Pour l'execution du code, deux fichier jar (dc et csec) ont été crées et ajoutés dans le repo voici leur méthode d'exécution dans le cmd

Pour DC

java -jar dc.jar folderpath(Ex:./jfreechart)
Pour CSEC

java -jar csec.jar folderpath(Ex:./jfreechart)
Les résultats du calcul des metriques peuvent être trouvés dans le dossier DATA METRICS du repo